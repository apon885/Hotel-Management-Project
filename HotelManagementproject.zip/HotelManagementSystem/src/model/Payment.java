package model;

import java.time.LocalDate;

public class Payment {
    private int id;
    private int reservationId;
    private double amount;
    private String paymentMethod;
    private LocalDate paymentDate;

    public Payment(int id, int reservationId, double amount, String paymentMethod, LocalDate paymentDate) {
        this.id = id;
        this.reservationId = reservationId;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.paymentDate = paymentDate;
    }

    // Getters and Setters
    public int getId() { return id; }
    public int getReservationId() { return reservationId; }
    public double getAmount() { return amount; }
    public String getPaymentMethod() { return paymentMethod; }
    public LocalDate getPaymentDate() { return paymentDate; }
    
    public void setId(int id) { this.id = id; }
    public void setReservationId(int reservationId) { this.reservationId = reservationId; }
    public void setAmount(double amount) { this.amount = amount; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }
}