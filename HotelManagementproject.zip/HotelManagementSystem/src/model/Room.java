package model;

public class Room {
    private int id;
    private String roomNumber;
    private String category;
    private double price;
    private String status;

    public Room(int id, String roomNumber, String category, double price, String status) {
        this.id = id;
        this.roomNumber = roomNumber;
        this.category = category;
        this.price = price;
        this.status = status;
    }

    // Getters and Setters
    public int getId() { return id; }
    public String getRoomNumber() { return roomNumber; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public String getStatus() { return status; }
    
    public void setId(int id) { this.id = id; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public void setCategory(String category) { this.category = category; }
    public void setPrice(double price) { this.price = price; }
    public void setStatus(String status) { this.status = status; }
}