package model;

public class Guest {
    private int id;
    private String name;
    private String contact;
    private String idProof;
    private int previousStays;

    public Guest(int id, String name, String contact, String idProof, int previousStays) {
        this.id = id;
        this.name = name;
        this.contact = contact;
        this.idProof = idProof;
        this.previousStays = previousStays;
    }

    // Getters and Setters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getContact() { return contact; }
    public String getIdProof() { return idProof; }
    public int getPreviousStays() { return previousStays; }
    
    public void setId(int id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setContact(String contact) { this.contact = contact; }
    public void setIdProof(String idProof) { this.idProof = idProof; }
    public void setPreviousStays(int previousStays) { this.previousStays = previousStays; }
}