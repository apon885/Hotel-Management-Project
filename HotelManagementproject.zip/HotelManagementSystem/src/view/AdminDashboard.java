package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminDashboard extends JFrame {
    public AdminDashboard() {
        setTitle("Hotel Management System - Admin Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JMenuBar menuBar = new JMenuBar();
        
        // Guest Management Menu
        JMenu guestMenu = new JMenu("Guest Management");
        JMenuItem viewGuestsItem = new JMenuItem("View Guests");
        guestMenu.add(viewGuestsItem);
        
        // Room Management Menu
        JMenu roomMenu = new JMenu("Room Management");
        JMenuItem viewRoomsItem = new JMenuItem("View Rooms");
        JMenuItem addRoomItem = new JMenuItem("Add Room");
        JMenuItem updatePricesItem = new JMenuItem("Update Room Prices");
        roomMenu.add(viewRoomsItem);
        roomMenu.add(addRoomItem);
        roomMenu.add(updatePricesItem);
        
        // Reports Menu
        JMenu reportsMenu = new JMenu("Reports");
        JMenuItem occupancyReportItem = new JMenuItem("Occupancy Report");
        JMenuItem financialReportItem = new JMenuItem("Financial Report");
        reportsMenu.add(occupancyReportItem);
        reportsMenu.add(financialReportItem);
        
        // Logout Menu
        JMenu logoutMenu = new JMenu("Logout");
        JMenuItem logoutItem = new JMenuItem("Logout");
        logoutMenu.add(logoutItem);
        
        menuBar.add(guestMenu);
        menuBar.add(roomMenu);
        menuBar.add(reportsMenu);
        menuBar.add(Box.createHorizontalGlue());
        menuBar.add(logoutMenu);
        
        setJMenuBar(menuBar);
        
        // Add welcome panel
        JPanel welcomePanel = new JPanel();
        welcomePanel.add(new JLabel("Welcome, Admin!"));
        add(welcomePanel, BorderLayout.CENTER);
        
        // Add action listeners
        viewGuestsItem.addActionListener(e -> {
            new GuestManagementFrame(true).setVisible(true);
        });
        
        viewRoomsItem.addActionListener(e -> {
            new RoomManagementFrame(true).setVisible(true);
        });
        
        addRoomItem.addActionListener(e -> {
            showAddRoomDialog();
        });
        
        updatePricesItem.addActionListener(e -> {
            showUpdatePricesDialog();
        });
        
        occupancyReportItem.addActionListener(e -> {
            showOccupancyReport();
        });
        
        financialReportItem.addActionListener(e -> {
            showFinancialReport();
        });
        
        logoutItem.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
    }
    
    private void showAddRoomDialog() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JTextField roomNumberField = new JTextField();
        JComboBox<String> categoryCombo = new JComboBox<>(new String[]{"STANDARD", "DELUXE"});
        JTextField priceField = new JTextField();
        
        panel.add(new JLabel("Room Number:"));
        panel.add(roomNumberField);
        panel.add(new JLabel("Category:"));
        panel.add(categoryCombo);
        panel.add(new JLabel("Price:"));
        panel.add(priceField);
        
        int result = JOptionPane.showConfirmDialog(this, panel, "Add New Room", 
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            // Validate and add room
            try {
                String roomNumber = roomNumberField.getText();
                String category = (String) categoryCombo.getSelectedItem();
                double price = Double.parseDouble(priceField.getText());
                
                // TODO: Call RoomController to add room
                JOptionPane.showMessageDialog(this, "Room added successfully!");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid price format", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void showUpdatePricesDialog() {
        // Similar to showAddRoomDialog but for updating prices
        // Implementation would show current prices and allow updates
    }
    
    private void showOccupancyReport() {
        // Implementation would show occupancy statistics
    }
    
    private void showFinancialReport() {
        // Implementation would show financial statistics
    }
}