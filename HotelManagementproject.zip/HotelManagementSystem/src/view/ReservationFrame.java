package view;


import controller.ReservationController;
import controller.RoomController;
import model.Guest;
import model.Room;
import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.List;

public class ReservationFrame extends JFrame {
    private final JComboBox<Guest> guestCombo;
    private final JComboBox<Room> roomCombo;
    private final JTextField checkInDateField;
    private final JTextField checkOutDateField;
    
    public ReservationFrame() {
        setTitle("New Reservation");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Guest selection
        mainPanel.add(new JLabel("Guest:"));
        guestCombo = new JComboBox<>();
        loadGuests();
        mainPanel.add(guestCombo);
        
        // Room selection
        mainPanel.add(new JLabel("Room:"));
        roomCombo = new JComboBox<>();
        loadAvailableRooms();
        mainPanel.add(roomCombo);
        
        // Check-in date
        mainPanel.add(new JLabel("Check-in Date (YYYY-MM-DD):"));
        checkInDateField = new JTextField(LocalDate.now().toString());
        mainPanel.add(checkInDateField);
        
        // Check-out date
        mainPanel.add(new JLabel("Check-out Date (YYYY-MM-DD):"));
        checkOutDateField = new JTextField(LocalDate.now().plusDays(1).toString());
        mainPanel.add(checkOutDateField);
        
        // Buttons
        JButton createButton = new JButton("Create Reservation");
        JButton cancelButton = new JButton("Cancel");
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(createButton);
        buttonPanel.add(cancelButton);
        
        add(mainPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Add action listeners
        createButton.addActionListener(e -> createReservation());
        cancelButton.addActionListener(e -> dispose());
    }
    
    private void loadGuests() {
        GuestController guestController = new GuestController();
        List<Guest> guests = guestController.getAllGuests();
        
        guestCombo.removeAllItems();
        for (Guest guest : guests) {
            guestCombo.addItem(guest);
        }
    }
    
    private void loadAvailableRooms() {
        RoomController roomController = new RoomController();
        List<Room> rooms = roomController.getAvailableRooms();
        
        roomCombo.removeAllItems();
        for (Room room : rooms) {
            roomCombo.addItem(room);
        }
    }
    
    private void createReservation() {
        try {
            Guest guest = (Guest) guestCombo.getSelectedItem();
            Room room = (Room) roomCombo.getSelectedItem();
            LocalDate checkInDate = LocalDate.parse(checkInDateField.getText());
            LocalDate checkOutDate = LocalDate.parse(checkOutDateField.getText());
            
            if (checkInDate.isAfter(checkOutDate)) {
                JOptionPane.showMessageDialog(this, "Check-in date must be before check-out date", 
                        "Invalid Dates", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            ReservationController reservationController = new ReservationController();
            // TODO: Create a Reservation object and pass to controller
            
            JOptionPane.showMessageDialog(this, "Reservation created successfully!");
            dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid date format (use YYYY-MM-DD)", 
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}