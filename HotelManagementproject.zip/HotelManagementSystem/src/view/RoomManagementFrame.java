package view;


import controller.RoomController;
import model.Room;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class RoomManagementFrame extends JFrame {
    private JTable roomTable;
    private final DefaultTableModel tableModel;
    
    public RoomManagementFrame(boolean isAdmin) {
        setTitle("Room Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Create table model
        String[] columnNames = {"ID", "Room Number", "Category", "Price", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0);
        
        // Create table
        roomTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(roomTable);
        
        // Create buttons
        JButton refreshButton = new JButton("Refresh");
        JButton updatePriceButton = new JButton("Update Price");
        JButton closeButton = new JButton("Close");
        
        if (!isAdmin) {
            updatePriceButton.setEnabled(false);
        }
        
        // Create button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(refreshButton);
        buttonPanel.add(updatePriceButton);
        buttonPanel.add(closeButton);
        
        // Add components to frame
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Load initial data
        refreshRoomTable();
        
        // Add action listeners
        refreshButton.addActionListener(e -> refreshRoomTable());
        
        updatePriceButton.addActionListener(e -> {
            int selectedRow = roomTable.getSelectedRow();
            if (selectedRow >= 0) {
                int roomId = (int) roomTable.getValueAt(selectedRow, 0);
                showUpdatePriceDialog(roomId);
            } else {
                JOptionPane.showMessageDialog(this, "Please select a room to update", 
                        "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        });
        
        closeButton.addActionListener(e -> dispose());
    }
    
    private void refreshRoomTable() {
        // Clear table
        tableModel.setRowCount(0);
        
        // Get rooms from controller
        RoomController roomController = new RoomController();
        List<Room> rooms = roomController.getAllRooms();
        
        // Add rooms to table
        for (Room room : rooms) {
            Object[] row = {
                room.getId(),
                room.getRoomNumber(),
                room.getCategory(),
                room.getPrice(),
                room.getStatus()
            };
            tableModel.addRow(row);
        }
    }
    
    private void showUpdatePriceDialog(int roomId) {
        RoomController roomController = new RoomController();
        Room room = roomController.getRoomById(roomId);
        
        if (room != null) {
            JPanel panel = new JPanel(new GridLayout(2, 2));
            JTextField priceField = new JTextField(String.valueOf(room.getPrice()));
            
            panel.add(new JLabel("Room Number:"));
            panel.add(new JLabel(room.getRoomNumber()));
            panel.add(new JLabel("New Price:"));
            panel.add(priceField);
            
            int result = JOptionPane.showConfirmDialog(this, panel, "Update Room Price", 
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            
            if (result == JOptionPane.OK_OPTION) {
                try {
                    double newPrice = Double.parseDouble(priceField.getText());
                    if (roomController.updateRoomPrice(roomId, newPrice)) {
                        JOptionPane.showMessageDialog(this, "Price updated successfully!");
                        refreshRoomTable();
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to update price", 
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Invalid price format", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
}