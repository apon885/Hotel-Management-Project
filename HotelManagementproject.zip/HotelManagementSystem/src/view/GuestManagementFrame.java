package view;


import model.Guest;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class GuestManagementFrame extends JFrame {
    private JTable guestTable;
    private final DefaultTableModel tableModel;
    
    public GuestManagementFrame(boolean isAdmin) {
        setTitle("Guest Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Create table model
        String[] columnNames = {"ID", "Name", "Contact", "ID Proof", "Previous Stays"};
        tableModel = new DefaultTableModel(columnNames, 0);
        
        // Create table
        guestTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(guestTable);
        
        // Create buttons
        JButton refreshButton = new JButton("Refresh");
        JButton updateButton = new JButton("Update Guest");
        JButton closeButton = new JButton("Close");
        
        if (!isAdmin) {
            updateButton.setEnabled(false);
        }
        
        // Create button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(refreshButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(closeButton);
        
        // Add components to frame
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Load initial data
        refreshGuestTable();
        
        // Add action listeners
        refreshButton.addActionListener(e -> refreshGuestTable());
        
        updateButton.addActionListener(e -> {
            int selectedRow = guestTable.getSelectedRow();
            if (selectedRow >= 0) {
                int guestId = (int) guestTable.getValueAt(selectedRow, 0);
                showUpdateGuestDialog(guestId);
            } else {
                JOptionPane.showMessageDialog(this, "Please select a guest to update", 
                        "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        });
        
        closeButton.addActionListener(e -> dispose());
    }
    
    private void refreshGuestTable() {
        // Clear table
        tableModel.setRowCount(0);
        
        // Get guests from controller
        GuestController guestController = new GuestController();
        List<Guest> guests = guestController.getAllGuests();
        
        // Add guests to table
        for (Guest guest : guests) {
            Object[] row = {
                guest.getId(),
                guest.getName(),
                guest.getContact(),
                guest.getIdProof(),
                guest.getPreviousStays()
            };
            tableModel.addRow(row);
        }
    }
    
    private void showUpdateGuestDialog(int guestId) {
        GuestController guestController = new GuestController();
        Guest guest = guestController.getGuestById(guestId);
        
        if (guest != null) {
            JPanel panel = new JPanel(new GridLayout(4, 2));
            JTextField nameField = new JTextField(guest.getName());
            JTextField contactField = new JTextField(guest.getContact());
            JTextField idProofField = new JTextField(guest.getIdProof());
            
            panel.add(new JLabel("Name:"));
            panel.add(nameField);
            panel.add(new JLabel("Contact:"));
            panel.add(contactField);
            panel.add(new JLabel("ID Proof:"));
            panel.add(idProofField);
            
            int result = JOptionPane.showConfirmDialog(this, panel, "Update Guest", 
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            
            if (result == JOptionPane.OK_OPTION) {
                // Update guest
                guest.setName(nameField.getText());
                guest.setContact(contactField.getText());
                guest.setIdProof(idProofField.getText());
                
                if (guestController.updateGuest(guest)) {
                    JOptionPane.showMessageDialog(this, "Guest updated successfully!");
                    refreshGuestTable();
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update guest", 
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
}