package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class ReceptionistDashboard extends JFrame {
    public ReceptionistDashboard() {
        setTitle("Hotel Management System - Receptionist Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JMenuBar menuBar = new JMenuBar();
        
        // Guest Management Menu
        JMenu guestMenu = new JMenu("Guest Management");
        JMenuItem viewGuestsItem = new JMenuItem("View Guests");
        JMenuItem addGuestItem = new JMenuItem("Add Guest");
        guestMenu.add(viewGuestsItem);
        guestMenu.add(addGuestItem);
        
        // Room Management Menu
        JMenu roomMenu = new JMenu("Room Management");
        JMenuItem viewRoomsItem = new JMenuItem("View Rooms");
        roomMenu.add(viewRoomsItem);
        
        // Reservation Menu
        JMenu reservationMenu = new JMenu("Reservation");
        JMenuItem newReservationItem = new JMenuItem("New Reservation");
        JMenuItem checkOutItem = new JMenuItem("Check Out");
        reservationMenu.add(newReservationItem);
        reservationMenu.add(checkOutItem);
        
        // Billing Menu
        JMenu billingMenu = new JMenu("Billing");
        JMenuItem generateInvoiceItem = new JMenuItem("Generate Invoice");
        billingMenu.add(generateInvoiceItem);
        
        // Reports Menu
        JMenu reportsMenu = new JMenu("Reports");
        JMenuItem reservationsReportItem = new JMenuItem("Reservations Report");
        reportsMenu.add(reservationsReportItem);
        
        // Logout Menu
        JMenu logoutMenu = new JMenu("Logout");
        JMenuItem logoutItem = new JMenuItem("Logout");
        logoutMenu.add(logoutItem);
        
        menuBar.add(guestMenu);
        menuBar.add(roomMenu);
        menuBar.add(reservationMenu);
        menuBar.add(billingMenu);
        menuBar.add(reportsMenu);
        menuBar.add(Box.createHorizontalGlue());
        menuBar.add(logoutMenu);
        
        setJMenuBar(menuBar);
        
        // Add welcome panel
        JPanel welcomePanel = new JPanel();
        welcomePanel.add(new JLabel("Welcome, Receptionist!"));
        add(welcomePanel, BorderLayout.CENTER);
        
        // Add action listeners
        viewGuestsItem.addActionListener(e -> {
            new GuestManagementFrame(false).setVisible(true);
        });
        
        addGuestItem.addActionListener(e -> {
            showAddGuestDialog();
        });
        
        viewRoomsItem.addActionListener(e -> {
            new RoomManagementFrame(false).setVisible(true);
        });
        
        newReservationItem.addActionListener(e -> {
            new ReservationFrame().setVisible(true);
        });
        
        checkOutItem.addActionListener(e -> {
            showCheckOutDialog();
        });
        
        generateInvoiceItem.addActionListener(e -> {
            showGenerateInvoiceDialog();
        });
        
        reservationsReportItem.addActionListener(e -> {
            showReservationsReport();
        });
        
        logoutItem.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
    }
    
    private void showAddGuestDialog() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JTextField nameField = new JTextField();
        JTextField contactField = new JTextField();
        JTextField idProofField = new JTextField();
        
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Contact:"));
        panel.add(contactField);
        panel.add(new JLabel("ID Proof:"));
        panel.add(idProofField);
        
        int result = JOptionPane.showConfirmDialog(this, panel, "Add New Guest", 
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            // Validate and add guest
            String name = nameField.getText();
            String contact = contactField.getText();
            String idProof = idProofField.getText();
            
            if (!name.isEmpty() && !contact.isEmpty() && !idProof.isEmpty()) {
                // TODO: Call GuestController to add guest
                JOptionPane.showMessageDialog(this, "Guest added successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "All fields are required", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void showCheckOutDialog() {
        // Implementation would show a dialog to select a reservation to check out
    }
    
    private void showGenerateInvoiceDialog() {
        // Implementation would show a dialog to generate an invoice for a reservation
    }
    
    private void showReservationsReport() {
        // Implementation would show reservations statistics
    }
}