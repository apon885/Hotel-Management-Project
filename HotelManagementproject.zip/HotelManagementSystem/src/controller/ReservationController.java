package controller;

import model.Database;
import model.Reservation;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReservationController {
    public boolean createReservation(Reservation reservation) {
        String sql = "INSERT INTO reservations(guest_id, room_id, check_in_date, check_out_date, status) " +
                     "VALUES(?, ?, ?, ?, ?)";
        try (Connection conn = Database.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, reservation.getGuestId());
            pstmt.setInt(2, reservation.getRoomId());
            pstmt.setString(3, reservation.getCheckInDate().toString());
            pstmt.setString(4, reservation.getCheckOutDate().toString());
            pstmt.setString(5, reservation.getStatus());
            pstmt.executeUpdate();
            
            // Update room status
            RoomController roomController = new RoomController();
            roomController.updateRoomStatus(reservation.getRoomId(), "OCCUPIED");
            
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public List<Reservation> getAllReservations() {
        List<Reservation> reservations = new ArrayList<>();
        String sql = "SELECT * FROM reservations";
        try (Connection conn = Database.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                reservations.add(new Reservation(
                    rs.getInt("id"),
                    rs.getInt("guest_id"),
                    rs.getInt("room_id"),
                    LocalDate.parse(rs.getString("check_in_date")),
                    LocalDate.parse(rs.getString("check_out_date")),
                    rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservations;
    }
    
    public boolean checkOut(int reservationId) {
        String sql = "UPDATE reservations SET status = 'CHECKED_OUT' WHERE id = ?";
        try (Connection conn = Database.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, reservationId);
            pstmt.executeUpdate();
            
            // Get room ID from reservation
            sql = "SELECT room_id FROM reservations WHERE id = ?";
            try (PreparedStatement pstmt2 = conn.prepareStatement(sql)) {
                pstmt2.setInt(1, reservationId);
                ResultSet rs = pstmt2.executeQuery();
                if (rs.next()) {
                    int roomId = rs.getInt("room_id");
                    // Update room status
                    RoomController roomController = new RoomController();
                    roomController.updateRoomStatus(roomId, "VACANT");
                }
            }
            
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}