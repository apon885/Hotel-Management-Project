package controller;

import model.Database;
import model.Payment;
import java.sql.*;
import java.time.LocalDate;

public class PaymentController {
    public boolean processPayment(Payment payment) {
        String sql = "INSERT INTO payments(reservation_id, amount, payment_method, payment_date) " +
                     "VALUES(?, ?, ?, ?)";
        try (Connection conn = Database.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, payment.getReservationId());
            pstmt.setDouble(2, payment.getAmount());
            pstmt.setString(3, payment.getPaymentMethod());
            pstmt.setString(4, payment.getPaymentDate().toString());
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public double calculateTotalRevenue() {
        String sql = "SELECT SUM(amount) FROM payments";
        try (Connection conn = Database.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
        }
        return 0;
    }
    
    public double calculateRevenueForPeriod(LocalDate startDate, LocalDate endDate) {
        String sql = "SELECT SUM(amount) FROM payments WHERE payment_date BETWEEN ? AND ?";
        try (Connection conn = Database.getInstance().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, startDate.toString());
            pstmt.setString(2, endDate.toString());
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}